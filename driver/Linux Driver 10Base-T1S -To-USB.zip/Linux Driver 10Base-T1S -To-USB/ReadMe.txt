1	Introduction

The LAN8670 USB Evaluation Board is a USB network adapter for a 10BASE-T1S network.
The device comes with drivers for Linux operating systems. Windows driver are currently at work.


1.1	Scope

This document describes the usage of the 10BASE-T1S USB Adapter in Windows and Linux operating systems. 
For support please contact our support team via the Microchip web portal:
http://www.microchip.com/support


2	Board basics

The board utilizes a Microchip LAN9500A to provide access to the 10BASE-T1S PHY LAN8670 via USB. The board hardware is described in the respective user's guide.


2.1	10BASE-T1S Network connection

The 10BASE-T1S network is using unshielded twisted pair cables for multidrop connection. The two wires are named N and P and should not be interchanged.


2.2	Termination

Terminations need to be active (both jumpers on the board closed) for the nodes located at the ends of a network. The nodes in between (drop nodes) do 
not require termination (both jumpers on the board open).


2.3	MAC Address

Each network adaptor has a pre-set unique MAC address. If you require the MAC address changed for individual purposes please contact:

http://www.microchip.com/support


2.4	PLCA

The PLCA Mechanism (Physical Layer Collision Avoidance) requires a dedicated node ID set on each node. 
In a 10BASE-T1S system there has to be one single PLCA master (node ID 0) and  at least one PLCA Slave (unique node ID >0). 
The node ID is set by the driver.


3	Software for Linux

All software to be used with the network adapter can be downloaded from the following download section:

https://microchiptechnology.sharepoint.com/:f:/s/FileSection/EkG40wvDbU9HpTMuqh93PBYB7_MTQvbUeM6eCH9I6NTs3A?e=GHPBgY

There is a separate folder for each software package.


3.1	Install Linux Driver on your own system

The available Linux driver for 10BASE-T1S USB Adapter was tested with Linux kernel 5.4.83. It can be downloaded from the 

/Software/Linux/Driver/

subfolder of the download section.
Please unzip the driver and copy the contents to the folder 

/Software/Linux/Driver/t1s-usb

to your Linux system and open a shell in this directory.
By executing

make

the driver kernel objects lan8767x_phy.ko and smsc95xx_t1s.ko are built.
Now please attach the 10BASE-T1S USB Adapter to your Linux device.
To load the driver you can use the script file t1s.sh with the node ID as parameter:

./t1s.sh 0 

for example loads the driver and configures the adapter as node 0 (PLCA master) and sets also the
IP address for the T1S adapter (via ifconfig) to 192.168.0.10.

./t1s.sh 1

loads the driver and configures the adapter as node 1 (PLCA slave) and sets the
IP address for the adapter to 192.168.0.11, and so on. 
Currently, only 2 node setups are supported.
If your setup requires more than 2 nodes please contact:

http://www.microchip.com/support

for additional configuration files.


3.2	Use Raspberry Pi image

If you use a Raspberry Pi test setup, a ready SD card image containing the driver is available in the subfolder:

/Software/Linux/RaspberryPI/

of the download section. This image can be transferred to a SD card by using SD or any disk imager software.

User:		pi
Password:	raspberry

The driver is located in the 

/home/pi/t1s-usb

directory.
Just enter this directory and call

make
 
When this is done, please call the script

./t1s.sh

with the desired node ID as parameter, to load the driver, for example

./t1s.sh 0 

for node 0 (PLCA master) or

./t1s.sh 1

for node 1 (PLCA slave).
