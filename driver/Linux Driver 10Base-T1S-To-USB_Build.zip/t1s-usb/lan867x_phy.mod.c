#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x4766f3ab, "module_layout" },
	{ 0x47e1f2cb, "genphy_suspend" },
	{ 0xb2192d12, "genphy_read_status" },
	{ 0xd117a43b, "phy_read_mmd" },
	{ 0xe84fe913, "phy_drivers_register" },
	{ 0xfd170424, "mdiobus_write" },
	{ 0xc452e249, "__genphy_config_aneg" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xc5850110, "printk" },
	{ 0xda7fcc44, "mdiobus_read" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0xb699cfb2, "genphy_aneg_done" },
	{ 0x64db1183, "genphy_resume" },
	{ 0xbddc46fb, "phy_drivers_unregister" },
	{ 0x380ccb0a, "genphy_soft_reset" },
	{ 0x5682a9fb, "request_firmware_direct" },
	{ 0xd2f25be3, "phy_write_mmd" },
	{ 0xd0e9fb09, "release_firmware" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("mdio:????000000000111110000010110????");

MODULE_INFO(srcversion, "EC082CB4F17D5F6369B0AFE");
