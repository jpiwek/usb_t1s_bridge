#!/bin/sh
#
# /*------------------------------------------------------------------------------------------------*/
# /* (c) 2021 Microchip Technology Inc. and its subsidiaries.                                       */
# /*                                                                                                */
# /* You may use this software and any derivatives exclusively with Microchip products.             */
# /*                                                                                                */
# /* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR    */
# /* STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,       */
# /* MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP       */
# /* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.                      */
# /*                                                                                                */
# /* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR        */
# /* CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE,    */
# /* HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE       */
# /* FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS   */
# /* IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE  */
# /* PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.                                                  */
# /*                                                                                                */
# /* MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.            */
# /*------------------------------------------------------------------------------------------------*/
#
# Some general hints:
# 
# How to check Kernel version
# uname -r
#
# Example how to get Kernel Headers
# sudo apt-get install raspberrypi-kernel-headers
# 
# Example how to install GCC
# sudo apt install build-essential
# 
# How to fix DKMS error (older kernel): "/bin/sh: 1: scripts/basic/fixdep: Exec format error" on make
# The kernel headers are cross compiled and there's a bug in deb-pkg that packs the build host executables rather than the target executables. Thankfully, the sources are also included with the headers so you just have to recompile the header scripts.
# There are 4 steps needed to do this:
# 1) Change to the Linux header directory: cd /usr/src/linux-headers-`uname -r`
# 1) Install the necessary dependencies: sudo apt-get install -y build-essential bc bison flex libssl-dev
# 2) Apply the byteshift patch to the headers: wget https://raw.githubusercontent.com/armbian/build/master/patch/misc/headers-debian-byteshift.patch -O - | sudo patch -p1
# 3) Compile the scripts: sudo make scripts
# 
#
# t1s.sh
# Roland Trissl (RTR)
# For support related to this code contact http://www.microchip.com/support

#Check, if config file exists
if [ ! -f "phy-driver/cfg/plca-8-$1.bin" ]; 
then
  echo "\033[31mThe required configuration file does not exist."
  echo "\033[31mPlease contact http://www.microchip.com/support"
else
  if [ $# -eq 1 ] 
  then
    echo "\033[36mConfigure 10BASE-T1S adapter as node $1:\033[0m"
    # Copy required configuration file
    sudo cp phy-driver/cfg/plca-8-$1.bin /lib/firmware/lan867x_config.bin
    # Remove old stuff if there
    echo "\033[36mRemoved drivers:\033[0m"
    lsmod | grep 'lan867x_phy'
    if [ $? -ne 0  ]
    then
      echo -
    else
      sudo rmmod lan867x_phy
    fi
    lsmod | grep 'smsc95xx_t1s'
    if [ $? -ne 0  ]
    then
      echo -
    else
      sudo rmmod smsc95xx_t1s
    fi
    sleep 2
    # Add the modules
    sudo insmod lan867x_phy.ko
    sleep 2
    sudo insmod smsc95xx_t1s.ko
    sleep 2
  fi

  if [ $# -eq 0 ] 
  then
    echo "\033[36mUsage: $0 0                 - Configures adapter as node 0 (PLCA coordinator) and sets up eth1.\033[0m"
    echo "\033[36m       $0 1                 - Configures adapter as node 1 and sets up eth1.\033[0m"
    echo "\033[36m       $0 7                 - Configures adapter as node 7 and sets up eth1.\033[0m"
    echo "\033[36m       $0 1 x               - Keeps driver configuration, just sets up eth1.\033[0m"
  else
    # Print info
    echo "\033[36mPresent drivers:\033[0m"
    lsmod | grep -iE "mchp|smsc|lan867x"
    # Check if adapter is present
    lsmod | grep 'lan867x_phy            16384  1' >/dev/null
    if [ $? -ne 0  ]
    then
      echo "\033[31mMCHP 10BASE-T1S adapter not found.\033[0m"
      #./t1s.sh
    else
      echo "\033[32mMCHP 10BASE-T1S adapter found.\033[0m"
      ipadr=`expr 10 + $1`
      sudo ifconfig eth1 192.168.0.$ipadr
      ifconfig eth1 | grep "inet "
    fi
    echo "\033[36mDone.\033[0m"
  fi
fi
