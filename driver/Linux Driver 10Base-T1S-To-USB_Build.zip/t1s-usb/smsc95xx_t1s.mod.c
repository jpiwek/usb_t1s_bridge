#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x4766f3ab, "module_layout" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xd949b296, "netdev_info" },
	{ 0x3351716f, "kmalloc_caches" },
	{ 0x6ba9bc0a, "ethtool_op_get_ts_info" },
	{ 0xf9a482f9, "msleep" },
	{ 0xa4a937c6, "phy_disconnect" },
	{ 0x7df72f89, "usbnet_resume" },
	{ 0x22fc42b4, "phy_stop" },
	{ 0xb2192d12, "genphy_read_status" },
	{ 0x3da8b2df, "usbnet_probe" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0x1e7cfa73, "phy_init_hw" },
	{ 0x95313822, "usbnet_link_change" },
	{ 0xb82b70d8, "__mdiobus_register" },
	{ 0x8c0696ba, "phy_ethtool_nway_reset" },
	{ 0xbc5c03ec, "usbnet_disconnect" },
	{ 0xba1f7ff2, "skb_clone" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0x5dffd6f8, "usbnet_defer_kevent" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xdfc1185f, "__dev_kfree_skb_any" },
	{ 0x29f48bdd, "usbnet_stop" },
	{ 0x69a4d9e9, "param_ops_bool" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x29d9f26e, "cancel_delayed_work_sync" },
	{ 0x67ea780, "mutex_unlock" },
	{ 0x691fec55, "mdiobus_unregister" },
	{ 0x526c3a6c, "jiffies" },
	{ 0x5a15740f, "skb_trim" },
	{ 0xf7af192a, "phy_print_status" },
	{ 0x79adf7af, "usbnet_set_link_ksettings" },
	{ 0x74e6a5b4, "phy_start" },
	{ 0x751a73e4, "phy_find_first" },
	{ 0xf3d0b495, "_raw_spin_unlock_irqrestore" },
	{ 0x1f593be3, "usbnet_get_stats64" },
	{ 0xe6bd5aaa, "usb_deregister" },
	{ 0xc5850110, "printk" },
	{ 0xc4b5eb92, "mdiobus_free" },
	{ 0x91eb0f9b, "usbnet_get_endpoints" },
	{ 0xda7fcc44, "mdiobus_read" },
	{ 0xf102732a, "crc16" },
	{ 0x4d5c0d82, "usbnet_get_link_ksettings" },
	{ 0xf33c2fe0, "usbnet_get_drvinfo" },
	{ 0x184ae64b, "skb_push" },
	{ 0x9579d0e2, "usbnet_read_cmd_nopm" },
	{ 0xc271c3be, "mutex_lock" },
	{ 0x80c4c319, "crc32_le" },
	{ 0xc8525cef, "usbnet_start_xmit" },
	{ 0x5c215af7, "usbnet_suspend" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0x83e548a4, "skb_pull" },
	{ 0x7052d249, "usbnet_write_cmd_nopm" },
	{ 0x2fbb3c53, "of_get_mac_address" },
	{ 0x370ef12a, "usbnet_read_cmd" },
	{ 0x405c31a5, "phy_connect_direct" },
	{ 0xcf86cdac, "queue_delayed_work_on" },
	{ 0xe92a07fa, "usbnet_tx_timeout" },
	{ 0x86332725, "__stack_chk_fail" },
	{ 0x4a024e0, "usbnet_skb_return" },
	{ 0xd4b24cfa, "usbnet_open" },
	{ 0xa845d867, "usbnet_get_msglevel" },
	{ 0xf11d67ab, "pskb_expand_head" },
	{ 0x9db79b95, "netdev_err" },
	{ 0x81f8ac7e, "kmem_cache_alloc_trace" },
	{ 0xde55e795, "_raw_spin_lock_irqsave" },
	{ 0xf1e8c0ee, "netdev_warn" },
	{ 0xe9d62ba6, "usb_autopm_get_interface_no_resume" },
	{ 0xc456140b, "eth_validate_addr" },
	{ 0x37a0cba, "kfree" },
	{ 0x1e3c1c2, "phy_attached_info" },
	{ 0x3074c476, "usbnet_write_cmd_async" },
	{ 0x9d664533, "usbnet_change_mtu" },
	{ 0xb1b79332, "usb_register_driver" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0x81e554cf, "phy_mii_ioctl" },
	{ 0x676bbc0f, "_set_bit" },
	{ 0xc358aaf8, "snprintf" },
	{ 0xe113bbbc, "csum_partial" },
	{ 0xa9029713, "eth_mac_addr" },
	{ 0x9fb36146, "usbnet_write_cmd" },
	{ 0xfe2fb2c0, "usbnet_set_msglevel" },
	{ 0xb57fd9d2, "usb_autopm_put_interface" },
	{ 0x5c70361f, "mdiobus_alloc_size" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v184Fp0051d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9500d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9505d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9E00d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9E01d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424pEC00d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9900d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9901d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9902d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9903d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9904d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9905d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9906d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9907d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9908d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9909d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9530d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9730d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0424p9E08d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "0F2B66BF5AB817EB00044B6");
